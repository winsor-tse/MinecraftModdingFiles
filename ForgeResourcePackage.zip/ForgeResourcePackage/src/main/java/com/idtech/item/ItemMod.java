package com.idtech.item;

import net.minecraft.item.Food;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class ItemMod {

    //BASIC ITEMS
    public static final Item STRUCTURE_GEL = ItemUtils.buildBasicItem("structuregel", ItemGroup.MISC);
    public static final Item GEL_ORE = ItemUtils.buildBasicItem("gelore", ItemGroup.MISC);
    //FOODS


    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {

        //BASIC ITEMS
        event.getRegistry().register(STRUCTURE_GEL);
        // ITEMS
        event.getRegistry().register(GEL_ORE);
        event.getRegistry().register(TeleportRodItem.INSTANCE);
        //

        //

        // TOOLS

        // FOOD

        // ARMOR

        //

        //

    }
}
